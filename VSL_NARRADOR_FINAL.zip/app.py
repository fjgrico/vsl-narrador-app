# app.py limpio

print('Hola desde app.py')
